#pragma once

#include "domain/Entity.h"
#include "domain/Vector2D.h"

namespace Flux::Domain {

    class PhysicsBody : public Entity {
    private:
        Vector2D m_position{ 0.0f, 0.0f };
        Vector2D m_velocity{ 0.0f, 0.0f };
        Vector2D m_force{ 0.0f, 0.0f };
        float m_mass{ 1.0f };
        bool m_isPinned{ false };

    public:
        PhysicsBody() = default;
        PhysicsBody(std::uint64_t id, std::string name, const Vector2D& pos, float mass = 1.0f)
            : Entity(id, std::move(name)), m_position(pos) {
            setMass(mass);
        }

        virtual ~PhysicsBody() override = default;

        // �������
        const Vector2D& getPosition() const noexcept { return m_position; }
        void setPosition(const Vector2D& pos) noexcept { m_position = pos; }

        
        const Vector2D& getVelocity() const noexcept { return m_velocity; }
        void setVelocity(const Vector2D& vel) noexcept { m_velocity = vel; }

        const Vector2D& getForce() const noexcept { return m_force; }
        void applyForce(const Vector2D& f) noexcept { m_force += f; }
        void clearForce() noexcept { m_force = { 0.0f, 0.0f }; }

        float getMass() const noexcept { return m_mass; }
        void setMass(float mass) noexcept {
            if (mass > 0.0001f) {
                m_mass = mass;
            }
        }

        // �������� ����
        bool isPinned() const noexcept { return m_isPinned; }
        void setPinned(bool pinned) noexcept { m_isPinned = pinned; }
    };

}