#pragma once

#include "domain/PhysicsBody.h"

namespace Flux::Domain {

    class PointCharge : public PhysicsBody {
    private:
        float m_charge{ 0.0f };
        float m_radius{ 6.0f };

    public:
        PointCharge() = default;
        PointCharge(std::uint64_t id, std::string name, const Vector2D& pos, float charge, float radius = 6.0f);

        float getCharge() const noexcept { return m_charge; }
        void setCharge(float q) noexcept { m_charge = q; }

        float getRadius() const noexcept { return m_radius; }
        void setRadius(float r) noexcept;
    };

}