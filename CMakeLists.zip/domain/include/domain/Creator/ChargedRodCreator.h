#pragma once


#include "domain/BodyCreator.h"
#include "../Tools/ChargedRod.h"

namespace Flux::Domain {
	class ChargedRodCreator :public BodyCreator {
	public:
		std::unique_ptr<PhysicsBody> create(std::uint64_t id, const Vector2D& position) const override;
	}
	;
}