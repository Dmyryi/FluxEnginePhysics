#pragma once

#include "domain/BodyCreator.h"

namespace Flux::Domain {

    class PointChargeCreator : public BodyCreator {
    public:
        std::unique_ptr<PhysicsBody> create(std::uint64_t id, const Vector2D& position) const override;
    };

}