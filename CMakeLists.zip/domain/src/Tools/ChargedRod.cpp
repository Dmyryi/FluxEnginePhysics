#include "../../include/domain/Tools/ChargedRod.h"

namespace Flux::Domain {

    ChargedRod::ChargedRod(std::uint64_t id, std::string name, const Vector2D& pos, float len, float q, float angle)
        : PhysicsBody(id, std::move(name), pos, 10.0f), m_totalCharge(q), m_angle(angle) {
        setLength(len);
    }

    void ChargedRod::setLength(float len) noexcept {
        if (len > 0.1f) {
            m_length = len;
        }
    }

}