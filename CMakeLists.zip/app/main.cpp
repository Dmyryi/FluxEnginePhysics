﻿#include <SFML/Graphics.hpp>
#include <imgui.h>
#include <imgui-SFML.h>

#include <vector>
#include <memory>

#include "presentation/Camera2D.h"
#include "domain/Creator/PointChargeCreator.h"
#include "domain/Creator/ChargedRodCreator.h"
#include "domain/Tools/PointCharge.h"
#include "domain/Tools/ChargedRod.h"
#include "../application/include/application/UseCase/SpawnBodyUseCase.h"

enum class ToolType {
    None,
    PointCharge,
    ChargedRod
};

int main() {
    sf::RenderWindow window(sf::VideoMode({ 1280u, 720u }), "FluxEngine - Viewport & Grid");
    window.setFramerateLimit(60);

    if (!ImGui::SFML::Init(window, false)) {
        return -1;
    }

    ImGui::GetIO().Fonts->AddFontDefault();
    if (!ImGui::SFML::UpdateFontTexture()) {
        return -1;
    }

    Flux::Presentation::Camera2D camera(1280.0f, 720.0f);
    sf::Clock deltaClock;

    // Контейнер тел и Use Case
    std::vector<std::unique_ptr<Flux::Domain::PhysicsBody>> bodies;
    Flux::Application::SpawnBodyUseCase spawnUseCase(bodies);

    // Создатели
    Flux::Domain::PointChargeCreator pointCreator;
    Flux::Domain::ChargedRodCreator rodCreator;

    ToolType activeTool = ToolType::PointCharge;

    while (window.isOpen()) {
        while (const auto event = window.pollEvent()) {
            ImGui::SFML::ProcessEvent(window, *event);

            // Обработка действий только если клик не внутри окна ImGui
            if (!ImGui::GetIO().WantCaptureMouse) {
                camera.handleEvent(*event, window);

                // Спавн по ЛКМ
                if (const auto* mouseBtn = event->getIf<sf::Event::MouseButtonPressed>()) {
                    if (mouseBtn->button == sf::Mouse::Button::Left && activeTool != ToolType::None) {
                        // Переводим пиксели окна в мировые координаты с учетом зума и сдвига камеры
                        camera.setViewTo(window);
                        sf::Vector2f worldPos = window.mapPixelToCoords(mouseBtn->position);
                        Flux::Domain::Vector2D spawnPos(worldPos.x, worldPos.y);

                        if (activeTool == ToolType::PointCharge) {
                            spawnUseCase.execute(pointCreator, spawnPos);
                        }
                        else if (activeTool == ToolType::ChargedRod) {
                            spawnUseCase.execute(rodCreator, spawnPos);
                        }
                    }
                }
            }

            if (event->is<sf::Event::Closed>()) {
                window.close();
            }

            if (const auto* resized = event->getIf<sf::Event::Resized>()) {
                camera.resetSize(static_cast<float>(resized->size.x), static_cast<float>(resized->size.y));
            }
        }

        ImGui::SFML::Update(window, deltaClock.restart());

        // --- Панель инструментов (Toolbar) ---
        ImGui::Begin("Tools & Simulation");

        ImGui::Text("Active Tool:");
        if (ImGui::RadioButton("Point Charge", activeTool == ToolType::PointCharge)) {
            activeTool = ToolType::PointCharge;
        }
        ImGui::SameLine();
        if (ImGui::RadioButton("Charged Rod", activeTool == ToolType::ChargedRod)) {
            activeTool = ToolType::ChargedRod;
        }
        ImGui::SameLine();
        if (ImGui::RadioButton("None (Pan only)", activeTool == ToolType::None)) {
            activeTool = ToolType::None;
        }

        ImGui::Separator();
        ImGui::Text("Bodies count: %zu", bodies.size());

        if (ImGui::Button("Clear All")) {
            bodies.clear();
        }

        ImGui::Separator();
        const auto& center = camera.getView().getCenter();
        ImGui::Text("Camera Pos: (%.1f, %.1f)", center.x, center.y);
        ImGui::End();

        // --- Рендеринг сцены ---
        window.clear(sf::Color(22, 24, 30));

        camera.setViewTo(window);
        camera.renderGrid(window);

        // Простой дебаг-рендер заспавненных тел
        for (const auto& body : bodies) {
            const auto& pos = body->getPosition();

            if (auto* pc = dynamic_cast<Flux::Domain::PointCharge*>(body.get())) {
                sf::CircleShape circle(pc->getRadius());
                circle.setOrigin({ pc->getRadius(), pc->getRadius() });
                circle.setPosition({ pos.x, pos.y });
                circle.setFillColor(pc->getCharge() >= 0.0f ? sf::Color(235, 64, 52) : sf::Color(52, 131, 235));
                window.draw(circle);
            }
            else if (auto* rod = dynamic_cast<Flux::Domain::ChargedRod*>(body.get())) {
                sf::RectangleShape rect({ rod->getLength(), 6.0f });
                rect.setOrigin({ rod->getLength() / 2.0f, 3.0f });
                rect.setPosition({ pos.x, pos.y });
                rect.setRotation(sf::radians(rod->getAngle()));
                rect.setFillColor(sf::Color(250, 180, 50));
                window.draw(rect);
            }
        }

        // Рендерим UI поверх сцены
        window.setView(window.getDefaultView());
        ImGui::SFML::Render(window);

        window.display();
    }

    ImGui::SFML::Shutdown();
    return 0;
}